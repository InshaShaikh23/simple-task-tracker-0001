import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";
import TaskList from "../components/TaskList";

function ViewTasks() {

  const [tasks, setTasks] = useState([]);
  const navigate = useNavigate();

  const fetchTasks = async () => {
    const res = await api.get("/");
    setTasks(res.data);
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  return (
    <div className="container">

      <button
        className="back-btn"
        onClick={() => navigate(-1)}
      >
        Back
      </button>

      <h2>All Tasks</h2>

      <TaskList
        tasks={tasks}
        fetchTasks={fetchTasks}
      />

    </div>
  );
}

export default ViewTasks;