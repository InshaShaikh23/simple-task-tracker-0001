import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="home">

      <h1>Task Tracker</h1>

      <p>Organize your daily tasks efficiently.</p>

      <div className="btn-container">

        <Link className="home-btn" to="/add">
          <button>Add New Task</button>
        </Link>

        <Link className="home-btn" to="/tasks">
          <button>View Tasks</button>
        </Link>

      </div>

    </div>
  );
}

export default Home;