import { useNavigate } from "react-router-dom";
import TaskForm from "../components/TaskForm";

function AddTask() {

  const navigate = useNavigate();

  return (
    <div className="container">

      <button
        className="back-btn"
        onClick={() => navigate("/")}
      >
        ← Home
      </button>

      <div className="card-box">
        <h2>Add Task</h2>
        <TaskForm />
      </div>

    </div>
  );
}

export default AddTask;