import TaskCard from "./TaskCard";

function TaskList({ tasks, fetchTasks }) {

  return (
    <>
      {tasks.map(task => (
        <TaskCard
          key={task._id}
          task={task}
          fetchTasks={fetchTasks}
        />
      ))}
    </>
  );
}

export default TaskList;