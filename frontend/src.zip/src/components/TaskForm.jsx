import { useState } from "react";
import api from "../api";

function TaskForm() {

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  const handleSubmit = async (e) => {

    e.preventDefault();

    if (!title || !description) {
      alert("Please fill all fields");
      return;
    }

    await api.post("/", {
      title,
      description
    });

    alert("Task Added Successfully");

    setTitle("");
    setDescription("");
  };

  return (
    <form onSubmit={handleSubmit}>

      <input
        type="text"
        placeholder="Enter Task Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />

      <textarea
        placeholder="Enter Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />

      <button className="submit-btn">
        Add Task
      </button>

    </form>
  );
}

export default TaskForm;