import { Link } from "react-router-dom";

function Navbar() {
return (
<nav className="navbar">
<Link to="/">Home</Link>
<Link to="/add">Add Task</Link>
<Link to="/tasks">View Tasks</Link>
</nav>
);
}

export default Navbar;