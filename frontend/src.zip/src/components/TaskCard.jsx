import api from "../api";

function TaskCard({ task, fetchTasks }) {

  const deleteTask = async () => {
    await api.delete(`/${task._id}`);
    fetchTasks();
  };

  const toggleStatus = async () => {
    await api.put(`/${task._id}`, {
      status:
        task.status === "Pending"
          ? "Completed"
          : "Pending"
    });

    fetchTasks();
  };

  return (
    <div className="task-card">

      <h3>{task.title}</h3>

      <p>{task.description}</p>

      <span className="status">
        {task.status}
      </span>

      <div className="card-buttons">

        <button
          className="toggle-btn"
          onClick={toggleStatus}
        >
          Toggle Status
        </button>

        <button
          className="delete-btn"
          onClick={deleteTask}
        >
          Delete
        </button>

      </div>

    </div>
  );
}

export default TaskCard;